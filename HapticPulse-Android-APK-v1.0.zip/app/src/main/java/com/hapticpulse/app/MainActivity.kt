package com.hapticpulse.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true

        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidHapticsBridge(this), "AndroidHaptics")

        // Загружает локальный автономный интерфейс из assets (или URL приложения)
        webView.loadUrl("file:///android_asset/index.html")
    }

    class AndroidHapticsBridge(private val context: Context) {
        private fun getVibrator(): Vibrator {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
        }

        @JavascriptInterface
        fun vibrateOneShot(durationMs: Long, amplitude: Int) {
            val vibrator = getVibrator()
            val safeAmp = amplitude.coerceIn(1, 255)
            val safeDur = durationMs.coerceIn(10L, 10000L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(safeDur, safeAmp))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(safeDur)
            }
        }

        @JavascriptInterface
        fun vibrateWaveform(patternJson: String, amplitudesJson: String) {
            val vibrator = getVibrator()
            val pArr = JSONArray(patternJson)
            val aArr = JSONArray(amplitudesJson)
            val timings = LongArray(pArr.length()) { i -> pArr.getLong(i) }
            val amplitudes = IntArray(aArr.length()) { i -> aArr.getInt(i).coerceIn(0, 255) }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(timings, -1)
            }
        }

        @JavascriptInterface
        fun cancel() {
            getVibrator().cancel()
        }
    }
}
